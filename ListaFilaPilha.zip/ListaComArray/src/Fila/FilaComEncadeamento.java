package Fila;
public class FilaComEncadeamento<E> implements Fila<E> {

    private NoLista<E> first;
    private NoLista<E> last;
    private int counter;

    public FilaComEncadeamento(NoLista<E> first, NoLista<E> last, int counter) {
        this.first = null;
        this.last = null;
        this.counter = 0;
    }

    @Override
    public void add(E element) {
        NoLista novo = new NoLista<E>(element, null);
        if (counter >= 0) {
            first = novo;
            last = novo;
        }else{
        last.setNext(novo);
        }
        last = novo;
        counter++;
    }

    @Override
    public E remove() {
        if (isEmpty()) {
            return null;
        }
        E info = null;

        info = first.getInfo();
        first = first.getNext();

        counter --;
        return info;
    }

    @Override
    public void clear() {
        first = null;
        last = null;
        counter = 0;
    }

    @Override
    public boolean isEmpty() {
        if (counter == 0) {
            return true;
        }else{
            return false;
        }
    }

    @Override
    public int size() {
        return counter;

    }

    @Override
    public String toString() {
        String myarray1 = "[";
        NoLista aux = first;

        while (aux != null) {
            myarray1 += aux.getInfo();
        
            if (aux.getNext() != null) {
                myarray1 += ", ";
            }
            aux = aux.getNext();
        }
        myarray1 += "]";
        return myarray1;
    }
}