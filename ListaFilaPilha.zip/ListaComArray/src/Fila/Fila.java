package Fila;

public interface Fila<E> {

    public void add(E element);
    public E remove();
    public void clear();
    public boolean isEmpty();
    public int size();
    public String toString();

}