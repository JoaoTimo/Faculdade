package Pilha;
public class Teste {
    
    public static void main(String[] args) {
        Pilha minPilha = new PilhaComEncadeamento();

        minPilha.push(80);
        minPilha.push(1);
        minPilha.push(45);
        System.out.println(minPilha);


        minPilha.pop();
        System.out.println(minPilha);
        
        minPilha.clear();
        
        System.out.println(minPilha);
        if (minPilha.top() == null) {
            System.out.println("Pilha vazia!");
        }
    }

}
