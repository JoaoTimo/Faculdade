package Pilha;

public interface Pilha <E> {

    public void push(E element);
    public E pop();
    public E top();
    public void clear();
    public boolean isEmpty();
    public int size();
    
} 
