package Pilha;

public class PilhaComEncadeamento<E> implements Pilha<E> {

    private NoLista<E> topNode;
    private int counter;

    public PilhaComEncadeamento() {
        this.topNode = null;
        this.counter = 0;
    }

    @Override
    public void push(E element) {
        NoLista<E> novo = new NoLista<E>(element, null);
        novo.setInfo(element);

            novo.setNext(topNode);
            topNode = novo;

        topNode = novo;
        counter++;
    }

    @Override
    public E pop() {

        E info = null;
        if (isEmpty()) {
            return null;
        }
        info = topNode.getInfo();
        topNode = topNode.getNext();
        counter--;
        return info;
    }

    @Override
    public E top() {
        if (isEmpty()) {
            return null;
        }
        return topNode.getInfo();
    }

    @Override
    public void clear() {
        this.topNode = null;
        this.counter = 0;
    }

    @Override
    public boolean isEmpty() {
        if (counter != 0) {
            return false;
        }
        return true;
    }

    @Override
    public int size() {
        return counter;
    }
    
    @Override
    public String toString() {
        String myarray1 = "[";
        NoLista<E> aux = topNode;

        while (aux != null) {
            myarray1 += aux.getInfo();
        
            if (aux.getNext() != null) {
                myarray1 += ", ";
            }
            aux = aux.getNext();
        }
        myarray1 += "]";
        return myarray1;
    }
}
