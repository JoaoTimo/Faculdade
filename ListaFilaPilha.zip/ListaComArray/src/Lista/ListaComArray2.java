package Lista;

public class ListaComArray2<E> implements Lista<E>{

    private E[] array;
    private int counter;
    private int capacity = 10;

    @SuppressWarnings("unchecked")
    public ListaComArray2() {
        array = (E[]) new Object[capacity];
        counter = 0;
    }

    private void ensureCapacity() {
        if (counter == capacity) {
            capacity *= 2;

            @SuppressWarnings("unchecked")
            E[] novo = (E[]) new Object[capacity];

            System.arraycopy(array, 0, novo, 0, counter);
            array = novo;
        }
    }

    @Override
    public void add(E element) {
        ensureCapacity();
        array[counter++] = element;
    }

    @Override
    public void add(int index, E element) {
        if (index < 0 || index > counter) {
            throw new IndexOutOfBoundsException();
        }

        ensureCapacity();

        for (int i = counter; i > index; i--) {
            array[i] = array[i - 1];
        }

        array[index] = element;
        counter++;
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        E removido = array[index];

        for (int i = index; i < counter - 1; i++) {
            array[i] = array[i + 1];
        }

        array[--counter] = null;
        return removido;
    }

    @Override
    public boolean removeFirst(E element) {
        int index = indexOf(element);
        if (index != -1) {
            remove(index);
            return true;
        }
        return false;
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        return array[index];
    }

    @Override
    public E set(int index, E element) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        E antigo = array[index];
        array[index] = element;
        return antigo;
    }

    @Override
    public void clear() {
        for (int i = 0; i < counter; i++) {
            array[i] = null;
        }
        counter = 0;
    }

    @Override
    public int size() {
        return counter;
    }

    @Override
    public boolean isEmpty() {
        return counter == 0;
    }

    @Override
    public boolean contains(E element) {
        return indexOf(element) != -1;
    }

    @Override
    public int indexOf(E element) {
        for (int i = 0; i < counter; i++) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int lastIndexOf(E element) {
        for (int i = counter - 1; i >= 0; i--) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public E[] toArray() {
        E[] novo = (E[]) new Object[counter];
        System.arraycopy(array, 0, novo, 0, counter);
        return novo;
    }

    @Override
    public String toString() {
        String saida = "[";
        for (int i = 0; i < counter; i++) {
            saida += array[i];
            if (i < counter - 1) {
                saida += ", ";
            }
        }
        return saida + "]";
    }
}