package Lista;
public class ListaComArray{
    
    private Integer[] array;
    private boolean resizable;
    private int initialCapacity;
    private int counter;
    private final static int X = 10;

    public ListaComArray(){
        this(10);
    }

    public ListaComArray(int initialCapacity) {
        this(initialCapacity, true);
    }

    public ListaComArray(int initialCapacity, boolean resizable) {
        this.array = new Integer[initialCapacity];
        this.counter = 0;
        this.resizable = resizable;
        this.initialCapacity = initialCapacity;
    }

    // ADD FINAL
    public boolean add(Integer obj) {
        if (isFull()) {
            if (resizable) {
                resizeArrayList();
            } else {
                return false;
            }
        }
        array[counter++] = obj;
        return true;
    }

    // ADD COM ÍNDICE
    public boolean add(int index, Integer element) {
        if (index < 0 || index > counter) return false;

        if (isFull()) {
            if (resizable) {
                resizeArrayList();
            } else {
                return false;
            }
        }

        for (int i = counter; i > index; i--) {
            array[i] = array[i - 1];
        }

        array[index] = element;
        counter++;
        return true;
    }

    // RESIZE
    private void resizeArrayList() {
        Integer[] novo = new Integer[array.length + X];
        System.arraycopy(array, 0, novo, 0, array.length);
        array = novo;
    }

    // REMOVE POR ÍNDICE
    public Integer remove(int index) {
        if (index < 0 || index >= counter) return null;

        Integer removido = array[index];

        for (int i = index; i < counter - 1; i++) {
            array[i] = array[i + 1];
        }

        array[counter - 1] = null;
        counter--;

        return removido;
    }

    // REMOVE PRIMEIRA OCORRÊNCIA
    public boolean removeFirst(Integer element) {
        int index = indexOf(element);
        if (index == -1) return false;

        remove(index);
        return true;
    }

    // GET
    public Integer get(int index) {
        if (index < 0 || index >= counter) return null;
        return array[index];
    }

    // CLEAR
    public void clear() {
        if (resizable) {
            array = new Integer[initialCapacity];
        } else {
            for (int i = 0; i < counter; i++) {
                array[i] = null;
            }
        }
        counter = 0;
    }

    // SET
    public Integer set(int index, Integer element) {
        if (index < 0 || index >= counter) return null;

        Integer antigo = array[index];
        array[index] = element;
        return antigo;
    }

    // SIZE
    public int size() {
        return counter;
    }

    // EMPTY
    public boolean isEmpty() {
        return counter == 0;
    }

    // FULL
    public boolean isFull() {
        if (resizable) return false;
        return counter == array.length;
    }

    // CONTAINS (correto agora)
    public boolean contains(Integer element) {
        return indexOf(element) != -1;
    }

    // INDEX OF
    public int indexOf(Integer element) {
        for (int i = 0; i < counter; i++) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    // LAST INDEX OF
    public int lastIndexOf(Integer element) {
        for (int i = counter - 1; i >= 0; i--) {
            if (array[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    // TO ARRAY
    public Integer[] toArray() {
        Integer[] novo = new Integer[counter];
        System.arraycopy(array, 0, novo, 0, counter);
        return novo;
    }

    // TO STRING
    @Override
    public String toString() {
        if (isEmpty()) return "[ ]";

        StringBuilder sb = new StringBuilder("[ ");
        for (int i = 0; i < counter; i++) {
            sb.append(array[i]);
            if (i < counter - 1) {
                sb.append(", ");
            }
        }
        sb.append(" ]");
        return sb.toString();
    }
}