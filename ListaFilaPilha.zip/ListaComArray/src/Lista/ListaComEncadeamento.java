package Lista;

public class ListaComEncadeamento<E> implements Lista<E> {

    private NoLista<E> first;
    private NoLista<E> last;
    private int counter;

    public ListaComEncadeamento() {
        this.first = null;
        this.last = null;
        this.counter = 0;
    }

    @Override
    public void add(E element) {
        NoLista<E> novo = new NoLista<>();
        novo.setInfo(element);

        if (counter == 0) {
            first = novo;
            last = novo;
        } else {
            last.setNext(novo);
            last = novo;
        }
        counter++;
    }

    @Override
    public void add(int index, E element) {
        if (index < 0 || index > counter) {
            throw new IndexOutOfBoundsException();
        }

        NoLista<E> novo = new NoLista<>();
        novo.setInfo(element);

        if (index == 0) {
            novo.setNext(first);
            first = novo;

            if (counter == 0) {
                last = novo;
            }
        } else {
            NoLista<E> aux = first;
            for (int i = 0; i < index - 1; i++) {
                aux = aux.getNext();
            }

            novo.setNext(aux.getNext());
            aux.setNext(novo);

            if (novo.getNext() == null) {
                last = novo;
            }
        }

        counter++;
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        NoLista<E> removido;

        if (index == 0) {
            removido = first;
            first = first.getNext();

            if (counter == 1) {
                last = null;
            }
        } else {
            NoLista<E> aux = first;
            for (int i = 0; i < index - 1; i++) {
                aux = aux.getNext();
            }

            removido = aux.getNext();
            aux.setNext(removido.getNext());

            if (removido == last) {
                last = aux;
            }
        }

        counter--;
        return removido.getInfo();
    }

    @Override
    public boolean removeFirst(E element) {
        NoLista<E> aux = first;
        NoLista<E> anterior = null;

        while (aux != null) {
            if (aux.getInfo().equals(element)) {

                if (anterior == null) { // primeiro
                    first = aux.getNext();

                    if (aux == last) {
                        last = null;
                    }
                } else {
                    anterior.setNext(aux.getNext());

                    if (aux == last) {
                        last = anterior;
                    }
                }
                counter--;
                return true;
            }
            anterior = aux;
            aux = aux.getNext();
        }
        return false;
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        NoLista<E> aux = first;

        for (int i = 0; i < index; i++) {
            aux = aux.getNext();
        }

        return aux.getInfo();
    }

    @Override
    public E set(int index, E element) {
        if (index < 0 || index >= counter) {
            throw new IndexOutOfBoundsException();
        }

        NoLista<E> aux = first;

        for (int i = 0; i < index; i++) {
            aux = aux.getNext();
        }

        E antigo = aux.getInfo();
        aux.setInfo(element);

        return antigo;
    }

    @Override
    public boolean contains(E element) {
        NoLista<E> aux = first;

        while (aux != null) {
            if (aux.getInfo().equals(element)) {
                return true;
            }
            aux = aux.getNext();
        }

        return false;
    }

    @Override
    public int indexOf(E element) {
        NoLista<E> aux = first;
        int index = 0;

        while (aux != null) {
            if (aux.getInfo().equals(element)) {
                return index;
            }
            aux = aux.getNext();
            index++;
        }

        return -1;
    }

    @Override
    public int lastIndexOf(E element) {
        NoLista<E> aux = first;
        int index = 0;
        int ultimo = -1;

        while (aux != null) {
            if (aux.getInfo().equals(element)) {
                ultimo = index;
            }
            aux = aux.getNext();
            index++;
        }

        return ultimo;
    }

    @Override
    public E[] toArray() {
        E[] array = (E[]) new Object[counter];

        NoLista<E> aux = first;
        int i = 0;

        while (aux != null) {
            array[i++] = aux.getInfo();
            aux = aux.getNext();
        }

        return array;
    }

    @Override
    public void clear() {
        first = null;
        last = null;
        counter = 0;
    }

    @Override
    public int size() {
        return counter;
    }

    @Override
    public boolean isEmpty() {
        return counter == 0;
    }

    @Override
    public String toString() {
        String saida = "[";
        NoLista<E> aux = first;

        while (aux != null) {
            saida += aux.getInfo();

            if (aux.getNext() != null) {
                saida += " ,";
            }

            aux = aux.getNext();
        }

        return saida + "]";
    }
}