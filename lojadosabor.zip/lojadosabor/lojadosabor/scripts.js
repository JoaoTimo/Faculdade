let elementoH1 = document.getElementById("loja");
elementoH1.remove();