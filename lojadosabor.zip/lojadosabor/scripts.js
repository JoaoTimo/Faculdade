(function() {

    $.ajax({
        beforeSend: function (request) {
            request.setRequestHeader("X-Api-Key", "wERLpAatb0B7Dkx7f32So6KTfWRe2cZ3PANlG2Zz");
        },
        type: "GET",
        url:"https://api.api-ninjas.com/v1/country?min_population=100",
        dataType: "json",
        success: function (dataNinja) {
            $('#myTable').DataTable({
                data: dataNinja,
                columns: [
                    { 'data' : 'name'},
                    { 'data' : 'capital'},
                    { 'data' : 'region'},
                    { 'data' : 'population'},
                    { 'data' : 'iso2'},
                    { 'data' : 'tourists'}
                ]
            });
            
        }
    });
})

