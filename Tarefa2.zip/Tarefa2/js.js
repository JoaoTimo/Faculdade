document.addEventListener("DOMContentLoaded",()=>{
    const mapa1 = document.getElementById("mapaMundo");
    
    const btMapa = document.getElementById("btnMapa");

    //mapa1.style.display = "none";

    btMapa.addEventListener("click",() => {
        if (mapa1.style.display === "none") {
            mapa1.style.display = "block";
        } else {
            mapa1.style.display = "none";
        }
    })
});